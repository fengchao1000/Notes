﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework.Mvc.Routing;
namespace Nop.Plugin.Payments.WeChatPay
{
    public partial class RouteProvider : IRouteProvider
    {
        /// <summary>
        /// Register routes
        /// </summary>
        /// <param name="routeBuilder">Route builder</param>
        public void RegisterRoutes(IEndpointRouteBuilder endpointRouteBuilder)
        {
            //WeChatScanCode
            endpointRouteBuilder.MapControllerRoute(WeChatPayDefaults.ScanCodeRouteName,
                 "Plugins/PaymentWeChatPay/WeChatScanCode/{ordercode}",
                 new { controller = "PaymentWeChatPay", action = "WeChatScanCode" }
                 //new[] { "Nop.Plugin.Payments.WeChatPay.Controllers" }
            );
            //MakePayQRCode
            endpointRouteBuilder.MapControllerRoute(WeChatPayDefaults.GenerateQRCodeRouteName,
                 "Plugins/PaymentWeChatPay/MakeQRCode",
                 new { controller = "PaymentWeChatPay", action = "MakeQRCode" }
                 //new[] { "Nop.Plugin.Payments.WeChatPay.Controllers" }
            );

            //Notify
            endpointRouteBuilder.MapControllerRoute(WeChatPayDefaults.NotifyRouteName,
                 "Plugins/PaymentWeChatPay/Notify",
                 new { controller = "PaymentWeChatPay", action = "Notify" }
                 //new[] { "Nop.Plugin.Payments.WeChatPay.Controllers" }
            );

            //Return
            endpointRouteBuilder.MapControllerRoute("Plugin.Payments.WeChatPay.Return",
                 "Plugins/PaymentWeChatPay/Return",
                 new { controller = "PaymentWeChatPay", action = "Return" }
                 //new[] { "Nop.Plugin.Payments.WeChatPay.Controllers" }
            );

            endpointRouteBuilder.MapControllerRoute(WeChatPayDefaults.RefundNotifyRouteName,
                 "Plugins/PaymentWeChatPay/RefundNotify",
                 new { controller = "PaymentWeChatPay", action = "RefundNotify" }
                 //new[] { "Nop.Plugin.Payments.WeChatPay.Controllers" }
            );
            endpointRouteBuilder.MapControllerRoute(WeChatPayDefaults.CheckOrderPaidRouteName,
                WeChatPayDefaults.CheckOrderPaidUrl+"/{ordercode}",
                new { controller = "PaymentWeChatPay", action = "CheckOrderPaid" }
           //new[] { "Nop.Plugin.Payments.WeChatPay.Controllers" }
           );
            endpointRouteBuilder.MapControllerRoute("RedirectToNmweb",
                  "Plugins/PaymentWeChatPay/RedirectToNweb" + "/{url}",
                  new { controller = "PaymentWeChatPay", action = "RedirectToNweb" }
             //new[] { "Nop.Plugin.Payments.WeChatPay.Controllers" }
             );

        }

        /// <summary>
        /// Gets a priority of route provider
        /// </summary>
        public int Priority
        {
            get { return -1; }
        }
    }
}
