﻿using Essensoft.AspNetCore.Payment.WeChatPay;
using Essensoft.AspNetCore.Payment.WeChatPay.Notify;
using Essensoft.AspNetCore.Payment.WeChatPay.Request;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Payments.WeChatPay.Models;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Security;
using Nop.Web.Framework.Controllers;
using QRCoder;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Nop.Plugin.Payments.WeChatPay.Controllers
{
    public partial class PaymentWeChatPayController : BasePaymentController
    {
        #region Fields

        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IOrderService _orderService;
        private readonly IPaymentService _paymentService;
        private readonly IPermissionService _permissionService;
        private readonly ILocalizationService _localizationService;
        private readonly ILogger _logger;
        private readonly INotificationService _notificationService;
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;
        private readonly IWebHelper _webHelper;
        private readonly IWorkContext _workContext;
        private readonly ShoppingCartSettings _shoppingCartSettings;

        private readonly IWeChatPayClient _payClient;
        private readonly IWeChatPayNotifyClient _notifyClient;
        private readonly WeChatPayPaymentSettings _weChatPayPaymentSettings;
        private readonly IOptions<WeChatPayOptions> _optionsAccessor;

        #endregion

        #region Ctor

        public PaymentWeChatPayController(
            IGenericAttributeService genericAttributeService,
            IOrderProcessingService orderProcessingService,
            IOrderService orderService,
            IPaymentService paymentService,
            IPermissionService permissionService,
            ILocalizationService localizationService,
            ILogger logger,
            INotificationService notificationService,
            ISettingService settingService,
            IStoreContext storeContext,
            IWebHelper webHelper,
            IWorkContext workContext,
            IWeChatPayClient payClient,
            IWeChatPayNotifyClient notifyClient,
            ShoppingCartSettings shoppingCartSettings,
            WeChatPayPaymentSettings weChatPayPaymentSettings,
            IOptions<WeChatPayOptions> optionsAccessor)
        {
            this._genericAttributeService = genericAttributeService;
            this._orderService = orderService;
            this._orderProcessingService = orderProcessingService;
            this._paymentService = paymentService;
            this._permissionService = permissionService;
            this._localizationService = localizationService;
            this._logger = logger;
            this._notificationService = notificationService;
            this._settingService = settingService;
            this._shoppingCartSettings = shoppingCartSettings;
            this._storeContext = storeContext;
            this._webHelper = webHelper;
            this._workContext = workContext;

            _payClient = payClient;
            _notifyClient = notifyClient;
            _weChatPayPaymentSettings = weChatPayPaymentSettings;
            _optionsAccessor = optionsAccessor;
        }

        #endregion

        #region Methods

        /// <summary>
        /// 选择微信支付后，重定向到扫码页面
        /// </summary>
        /// <param name="ordercode"></param>
        /// <returns></returns>
        /// 
        
        public IActionResult RedirectToNweb(string url)
        {
            return Redirect(url);
        }
        public IActionResult WeChatScanCode(string ordercode)
        {
            var model = new WeChatScanCodeModel();
            model.OrderCode = ordercode;
            //this.RouteData
            return View("~/Plugins/Payments.WeChatPay/Views/WeChatScanCode.cshtml", model);
        }

        /// <summary>
        /// 获取到微信支付二维码
        /// </summary>
        /// <param name="ordercode"></param>
        /// <returns></returns>
        public async Task<IActionResult> MakeQRCode(string ordercode)
        {
            if(String.IsNullOrEmpty(ordercode) || ordercode.Length != 32)
            {
                return File("/content/default-image.gif", "image/gif");
            }
            var order = _orderService.GetOrderByGuid(new Guid( ordercode));
            if (order == null)
            {
                return File("/content/default-image.gif", "image/gif");
            }

           // string testNotifyUrl = "https://114.88.48.99/" + WeChatPayDefaults.NotifyUrl ;
            string realNotifyUrl = _webHelper.GetStoreHost(_storeContext.CurrentStore.SslEnabled
                    && !String.IsNullOrWhiteSpace(_storeContext.CurrentStore.Url))
                    + WeChatPayDefaults.NotifyUrl;

            var request = new WeChatPayUnifiedOrderRequest
            {
                Body = GetBody(order, _orderService),
                OutTradeNo = order.OrderGuid.ToString("N"),
                TotalFee = Convert.ToInt32(order.OrderTotal * 100),
                SpBillCreateIp = _webHelper.GetCurrentIpAddress(),
                NotifyUrl = realNotifyUrl,
                TradeType = WeChatPayDefaults.TradeType
            };
            var response = await _payClient.ExecuteAsync(request,_optionsAccessor.Value);
            // response.CodeUrl 给前端生成二维码
            ViewData["qrcode"] = response.CodeUrl;
            ViewData["response"] = response.Body;

            //将字符串生成二维码图片
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(response.CodeUrl, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);
            //Bitmap image = qrCodeEncoder.Encode(result.CodeUrl, Encoding.Default);

            //保存为PNG到内存流  
            MemoryStream ms = new MemoryStream();
            qrCodeImage.Save(ms, ImageFormat.Jpeg);

            return File(ms.GetBuffer(), "image/jpeg");   
        }
        public async Task<IActionResult> CheckOrderPaid(string orderCode)
        {
            
            var request = new WeChatPayOrderQueryRequest
            {
                OutTradeNo = orderCode
            };
            var notify = await _payClient.ExecuteAsync(request, _optionsAccessor.Value);
            if (notify.ReturnCode == "SUCCESS")
            {
                if (notify.ResultCode == "SUCCESS")
                {
                    //Console.WriteLine("OutTradeNo: " + notify.OutTradeNo);
                    var order = _orderService.GetOrderByGuid(new Guid(notify.OutTradeNo));
                    if (order == null)
                    {
                        return WeChatPayNotifyResult.Failure;
                    }

                    if (notify.TotalFee != Convert.ToInt32((order.OrderTotal * 100).ToString()))
                    {
                        return WeChatPayNotifyResult.Failure;
                    }
                    if (order != null && _orderProcessingService.CanMarkOrderAsPaid(order))
                    {
                        order.AuthorizationTransactionCode = notify.TransactionId;
                        order.AuthorizationTransactionId = notify.TransactionId;
                        order.SubscriptionTransactionId = notify.TransactionId;
                        order.CaptureTransactionId = notify.TransactionId;
                        order.CaptureTransactionResult = notify.TransactionId;
                        _orderProcessingService.MarkOrderAsPaid(order);
                    }

                    return WeChatPayNotifyResult.Success;
                }
            }
           return  Redirect(@"\order\history");
        }


        [HttpPost]
        public async Task<IActionResult> Notify()
        {
          //  _logger.InsertLog(Request.Body);
            try
            {
                var notify = await _notifyClient.ExecuteAsync<WeChatPayUnifiedOrderNotify>(Request,_optionsAccessor.Value);
                if(notify == null)
                    return NoContent();
                _logger.Information(notify.Body);//记录一下回调通知日志，正式应用删除
                if (notify.ReturnCode == "SUCCESS")
                {
                    if (notify.ResultCode == "SUCCESS")
                    {
                        _logger.Information("seems Success");
                        //Console.WriteLine("OutTradeNo: " + notify.OutTradeNo);
                        var order = _orderService.GetOrderByGuid(new Guid(notify.OutTradeNo));
                        _logger.Information("order id is " + order.Id.ToString() + "guid is" + order.OrderGuid.ToString());
                        if (order == null)
                        { 
                            _logger.Information("order is null,so fail");
                            return WeChatPayNotifyResult.Failure;
                           
                        }
                        
                        int orderFee = (int)(order.OrderTotal * 100);
                        if (notify.TotalFee != orderFee)
                        {
                            _logger.Information("fee not equal,order fee is " + orderFee.ToString() + " notify fee is " + notify.TotalFee.ToString());
                            return WeChatPayNotifyResult.Failure;
                        }
                        if (order != null && _orderProcessingService.CanMarkOrderAsPaid(order))
                        {
                            order.AuthorizationTransactionCode = notify.TransactionId;
                            order.AuthorizationTransactionId = notify.TransactionId;
                            order.SubscriptionTransactionId = notify.TransactionId;
                            order.CaptureTransactionId = notify.TransactionId;
                            order.CaptureTransactionResult = notify.TransactionId;
                            _orderProcessingService.MarkOrderAsPaid(order);
                            _logger.Information("success marked the order as paid");

                        }

                        return WeChatPayNotifyResult.Success;
                    }
                }
                return NoContent();
            }
            catch(Exception ex)
            {
                _logger.Information(ex.Message);
                return NoContent();
            }
        }

        //[AcceptVerbs(HttpVerbs.Get | HttpVerbs.Post)]
        [HttpPost()]
        [HttpGet()]
        public async Task<IActionResult> RefundNotify()
        {
            try
            {
                var notify = await _notifyClient.ExecuteAsync<WeChatPayRefundNotify>(Request,_optionsAccessor.Value);
                if (notify == null)
                    return NoContent();
                _logger.Information("退款信息：" + notify.Body);
                if (notify.ReturnCode == "SUCCESS")
                {
                    if (notify.RefundStatus == "SUCCESS")
                    {
                        Console.WriteLine("OutTradeNo: " + notify.OutTradeNo);
                        return WeChatPayNotifyResult.Success;
                    }
                }
                return NoContent();
            }
            catch
            {
                return NoContent();
            }
        }

        #endregion

        #region

        public static string GetBody(Order order,IOrderService orderService, int length = 63)
        {
            string body = "";
            int p = 0;
            var orderItems = orderService.GetOrderItems(order.Id);
            int count = orderItems.Count;

            foreach (OrderItem item in orderItems.OrderBy(oi => oi.Id))
            {
                body = body + orderService.GetProductByOrderItemId(item.Id).Name;
                if (p < count - 1)
                {
                    body = body + "|";
                }
                p++;
            }
            if (body.Length > length)
            {
                body = body.Substring(0, length);
            }
            return body.Trim().Replace('&', '_').Replace('=', '_');
        }

        public string GetBody(IList<Order> orders,IOrderService orderService, int length = 224)
        {
            string body = "";

            if (orders.Count > 0)
            {
                length = length / orders.Count;
            }

            foreach (var order in orders)
            {
                var orderItems = orderService.GetOrderItems(order.Id);
                int count = orderItems.Count;
                if (count == 0)
                    continue;
                int p = 0;
                string tmp = "";
                foreach (OrderItem item in orderItems)
                {
                    tmp = tmp + orderService.GetProductByOrderItemId(item.Id).Name;
                    if (p < count - 1)
                    {
                        tmp = tmp + "|";
                    }
                    p++;
                }
                if (tmp.Length > length)
                {
                    tmp = tmp.Substring(0, length);
                }

                body += tmp;
            }
            return body;
        }

        #endregion
    }
}