﻿namespace Nop.Plugin.Payments.WeChatPay.Models
{
    public partial class WeChatScanCodeModel
    {
        //
        public string OrderCode { get; set; }
    }
}
