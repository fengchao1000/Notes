﻿namespace Nop.Plugin.Payments.AliPay.Models
{
    public partial class AliPayScanCodeModel
    {
        //
        public string OrderCode { get; set; }
    }
}
