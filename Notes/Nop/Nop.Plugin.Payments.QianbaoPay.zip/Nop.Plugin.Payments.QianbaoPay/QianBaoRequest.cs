﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Azure.Storage.Blob.Protocol;

namespace Nop.Plugin.Payments.QianBaoPay
{
    public class QianBaoRequest
    {
        public string OrderNo { get; set; }
        public Decimal OrderAmount { get; set; }
        public DateTime OrderTime { get; set; }
        public string ProductName { get; set; }
        public string PayType { get; set; } = "PT001";
        public string PageUrl { get; set; }
        public string NotifyUrl { get; set; }
        public string BuyerIp { get; set; }
        public string InstCode { get; set; }
        public string AccNo { get; set; }
        public string PayerMobileNo { get; set; }
        

    }
}
