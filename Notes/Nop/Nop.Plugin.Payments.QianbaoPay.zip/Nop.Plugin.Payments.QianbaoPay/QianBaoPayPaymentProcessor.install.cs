﻿
using Microsoft.AspNetCore.Mvc;
using Nop.Core.Domain.Orders;
using Nop.Services.Payments;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Nop.Plugin.Payments.QianBaoPay
{
    /// <summary>
    ///钱宝支付，支持手机网站支付、电脑网站支付,
    /// </summary>
    public partial class QianBaoPaymentProcessor
    {

        /// <summary>
        /// Install the plugin
        /// </summary>
        public override void Install()
        {
            //settings
            _settingService.SaveSetting(new QianBaoPaymentSettings
            {
                AdditionalFeePercentage = true,
                AdditionalFee = 0,
                LogLevel = Microsoft.Extensions.Logging.LogLevel.Error
            });

            //locales
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.MerchantId", "商户号");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.MerchantId.Hint", "商户 Id");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.SignType", "签名方式");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.SignType.Hint", "签名方式");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.VerifyKey", "钱宝公钥");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.VerifyKey.Hint", "输入钱宝公钥");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.SignKey", "应用私钥");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.SignKey.Hint", "应用私钥");

            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.EncyptKey", "EncyptKey");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.EncyptKey.Hint", "EncyptKey");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.ServerUrl", "钱宝网关");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.ServerUrl.Hint", "这里要注意沙箱环境的网关地址为：https://openapi.alipaydev.com/gateway.do");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.Version", "接口版本");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.Version.Hint", "接口版本");

           
            
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.Charset", "编码格式");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.Charset.Hint", "编码格式");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.EncyptType", "加密方式");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.EncyptType.Hint", "加密方式");
      


            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.AdditionalFee", "附加费");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.AdditionalFee.Hint", "附加费");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.AdditionalFeePercentage", "附加费比例");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.AdditionalFeePercentage.Hint", "附加费比例");

            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.Instructions", "钱宝支付");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.ScanQRCode", "确认订单后，会出现支付二维码，请使用扫一扫功能，进行支付。");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.RedirectionTip", "确认订单后，将打开在线支付页面，进行支付。");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.QianBaoPay.PaymentMethodDescription", "钱宝支付，支持手机网站支付、电脑网站支付");
            //  paymentmethoddescription

            base.Install();
        }

        /// <summary>
        /// Uninstall the plugin
        /// </summary>
        public override void Uninstall()
        {
            //settings
            _settingService.DeleteSetting<QianBaoPaymentSettings>();

            //locales
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.MerchantId");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.MerchantId.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.VerifyKey");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.VerifyKey.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.SignKey");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.SignKey.Hint");
       
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.ServerUrl");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.ServerUrl.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.Version");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.Version.Hint");



            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.SignType");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.SignType.Hint");

            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.Charset");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.Charset.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.EncyptType");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.EncyptType.Hint");


            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.AdditionalFee");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.AdditionalFee.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.AdditionalFeePercentage");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.AdditionalFeePercentage.Hint");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.Instructions");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.ScanQRCode");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.RedirectionTip");
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.QianBaoPay.PaymentMethodDescription");

            base.Uninstall();
        }
    }
}
