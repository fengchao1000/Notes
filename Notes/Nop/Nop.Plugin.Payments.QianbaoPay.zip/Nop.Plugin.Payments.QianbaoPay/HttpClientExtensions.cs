﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Payments.QianBaoPay
{
    public static class HttpClientExtensions
    {
        /// <summary>
        /// 执行HTTP POST请求。
        /// </summary>
        /// <param name="client">HttpClient</param>
        /// <param name="url">请求地址</param>
        /// <param name="textParams">请求参数</param>
        /// <returns>响应内容</returns>
        public static async Task<string> PostAsync(this HttpClient client, string url, IDictionary<string, string> textParams)
        {
            string queryString = QianBaoPayUtility.BuildQuery(textParams);


            using (var reqContent = new StringContent(QianBaoPayUtility.BuildQuery(textParams), Encoding.UTF8, "application/x-www-form-urlencoded"))
            using (var resp = await client.PostAsync(url+"?"+queryString, null))
            using (var respContent = resp.Content)
            {
                string s= await respContent.ReadAsStringAsync();
                return s;
               // return await respContent.ReadAsStringAsync();
            }
         


        }
    }
}