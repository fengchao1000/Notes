﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.QianBaoPay
{
    public class QianBaoResponse
    {
       public  string Body { get; set; }
    }
}
