﻿namespace Nop.Plugin.Payments.QianBaoPay.Models
{
    public partial class QianBaoPayScanCodeModel
    {
        //
        public string OrderCode { get; set; }
    }
}
