﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.QianBaoPay.Models
{
    public abstract class QianBaoPayObject
    {
    }
}
