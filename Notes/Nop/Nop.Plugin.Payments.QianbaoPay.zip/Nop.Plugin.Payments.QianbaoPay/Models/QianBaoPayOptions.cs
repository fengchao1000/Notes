﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.QianBaoPay
{
    public class QianBaoPayOptions
    {
      

        public string Name { get; set; } = "B2CPayment";
        public string Version { get; set; } ="V1.0";
        /// <summary>
        /// 编码格式
        /// "utf-8"
        /// </summary>
        public string Charset { get; } = "utf-8";

        //商户号：
        public string MsgSender { get; set; }
        /// <summary>
        
        /// </summary>
       
        /// <summary>
        /// 服务地址
        /// "https://ipaytest.fortunebill.com/mas/dforder/pay.do"
        /// </summary>
        public string ServerUrl { get; set; } = "https://ipaytest.fortunebill.com/mas/dforder/pay.do";

        /// <summary>
        /// 数据格式
        /// "json"
        /// </summary>
      
        public string SignType { get; set; } = "RSA2";


        /// <summary>
        /// 日志等级
        /// </summary>
       
        public string SignKey { get; set; } = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCtwz5WQBNA+R/k\n" +
            "9ZELlELhle7IAWEATxGkg7As04xdkOgba1nEKYXD7/BrBnjEvITgnAcIT79Xz4vh\n" +
            "tHu06FxcnXrEF7wuiUc5fFUwJiGQFlsbxlhue4z3PZ86QfP8f1RhcADMtPwQ3tE6\n" +
            "fQNyzgwbkDRmJu/YXI0O62ahTWPOmCz+Vbfp6NzSo1+je3bnLNE8ozZP1GR4BoRw\n" +
            "ZcOKmTujeIe6d33BYZ9CqwrC4g9NJupl42+f5vR2q0aObsRILFuC+4uXsc4OOrWX\n" +
            "xkldFnbyYrPMMm1otQVifg4Ppm/3u0IbdxkIcXqamTAwXJxokxzyenjCxJQHWmu1\n" +
            "ApL6SZRlAgMBAAECggEAEOT+1pv8Q0D1nOlTZPDRX+WYBdI8gC8v4/L52iHnb+F6\n" +
            "78+MNspiux5FHeLPMzGxKbWB6Yj3ba48R4Go1XoSIN8e5Jn6Lfwi9K/mCHxsnvnN\n" +
            "efHa/0L7/b38EUoAUvh+V8rwCPc/2tQPO8ST5UGrY7KtpZD7mOnGvUCeBejkX127\n" +
            "TTn/mgWqJgAmsOhxGFVV781Z0etODvI1QX1seH30PgONG7xsUSR83804DdJFy9H2\n" +
            "Hqj7phxDSyH/lRlwndwQ8+mXyHSzHSm0KJZxZQOElj0LExqIMAIXCms9VwPs8u7V\n" +
            "Icb2b8UiNG6OiMiTZhgmXhDNDl0k2G6pUsFLYpGHsQKBgQDfeEikeio/YHBE+/U2\n" +
            "1JwbZE4j9KBPDQePkTbkV57xc3o/x832YvUApoapOmA03MXfM0w0WJ6rc7ysJvLY\n" +
            "RZCV1Mcai3bXbRAtEDmORcvYCoWNrXUHK/wtkhFeGMmyILmbIxTbUC4I8XXffQwZ\n" +
            "7NtT7h+noMdp3FX4N9tPGcGA+wKBgQDHDpixkUfZPbfRK6g9JhLJ4yDHLTJ6P8GP\n" +
            "UdFDj8RDmZVgkGk+1C/0F6OAv4jwiCxBVF/bYAjARwSry+HmQMXskk0KmPygvUGf\n" +
            "GLiF64sot+iqsbf2xJXZFE9y951tDVU3GK5n3/lw9Hoi7TQO1JrXEeMg4AMkeugY\n" +
            "y6HLrTsCHwKBgCuyaon29XHlGq7ykbWCB3B3wavYNsyeYJ8bJx+pXoQaL4pvOH/4\n" +
            "Q6434dcPeiZ8ERke/8Swm34tKHSFPTE7ERWrQK+ZG8juI56cMJT4Yu7Ax/K3O04G\n" +
            "tM34ZPsAX9g7++8xAfAMkqPfC0yDOC2NmimkQ35UuwmhMxJRYcnq4GKnAoGAUPEN\n" +
            "g/7YYWzoRwTil2LY9wEFfhhR00YDlhyl5DwciYR1Klvuf97WVQIbuSmpLG2i2TnO\n" +
            "9Kx7QnxeWOFBzVf/Y3AmJa4J4+6xNVlfBw29e2Q1FtvHO2+6oxfQKqanfAWU5h+C\n" +
            "I7j+fEDdPUCJD5LCF7wtSFvuyzGzGQoMk36wZO8CgYEAzgo7x/v534U++u1JdjAJ\n" +
            "2ycraPNBo7d01w1q7qpXam7AWdLYaEgIi18T4ZzShSCpWdBupwlS/LCkChNjqJ9a\n" +
            "sSvRxGDZiASCmA1Uh7+YWTQhyM7jH7Ff6OO8dg/yaMcDIJt8w19tgWGCvOscLIs1\n" +
            "x9YlZem3lgG9Dqp+locPvLM=";
        public string VerifyKey { get; set; } = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqWzfz5+mPFxPEl9LauaL\n" +
                "aeyjl+qqL7p9o8+8+rN+w0hxpfFXzh1m75ZLuhTx2aWcMdJ+UvZrvxpuQpg+3HWB\n" +
                "Mc5lTbFEhPqRPDyJqtukNw/5OaXl+MkWIBHqhjWX1iOWatxL/1WDmnzgsxJbvunr\n" +
                "WQjBfIa5sAgyH9QRYBFcpxtTkDiTdS/xNXgtvZg+OAe5T5Yea2t2Wrglf1woPtu2\n" +
                "0y/UrY2qPfZP6/9wYHUOTRh8j8TBG4iwgV6S6CoRMfLoIlUBTFP/F3bHCRUF6yT/\n" +
                "FFqmNLhXHVtfySHb12g0DKaJdi2a6y3L4p9sfCGvWf8AH/fISlurCTQdSOk2rXOE\n" +
                "hQIDAQAB";
    }
}
