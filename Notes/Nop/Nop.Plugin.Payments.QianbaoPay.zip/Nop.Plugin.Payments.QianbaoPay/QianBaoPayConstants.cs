﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.QianBaoPay
{
    public class QianBaoPayConstants
    {
        public const string Name = "Name";
        public const string Version = "Version";
        public const string Charset = "Charset";
        public const string MsgSender = "MsgSender";
      
        public const string OrderNo = "OrderNo";
        public const string OrderAmount = "OrderAmount";
        public const string OrderTime = "OrderTime";
        public const string SendTime = "SendTime";
        public const string PayType = "PayType";
        public const string PageUrl = "PageUrl";
        public const string NotifyUrl = "NotifyUrl";
        public const string ProductName = "ProductName";
        public const string SignType = "SignType";
        public const string SignMsg = "SignMsg";
        public  const string BuyerIp = "BuyerIp";

        //手机号码，该字段不参与签名
        public const string PayerMobileNo = "PayerMobileNo";
       
        //付款卡号，付款人卡号。建议上送，不上送无法直连银联快捷，需跳转至钱宝收银台进行输入。该字段不参与签名
        public const string AccNO = "AccNo";

        //回调通知中的签名
        public const string Digest = "digest";
       
    }
}
