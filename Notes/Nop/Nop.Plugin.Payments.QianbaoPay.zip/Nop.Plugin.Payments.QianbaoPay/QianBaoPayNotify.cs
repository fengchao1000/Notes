﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;
using Nop.Plugin.Payments.QianBaoPay.Models;
namespace Nop.Plugin.Payments.QianBaoPay
{
    public class QianBaoPayNotify : QianBaoPayObject
    {
        

        //
        // 摘要:
        //     版本号
        [JsonPropertyName("version")]
        public string Version { get; set; }
        //
        // 摘要:
        //     支付产品，W01-微信扫码支付
        /*
           W02-微信公众号支付
           W03-微信刷卡（反扫）
           W04-微信H5支付
           W05-微信APP支付
           A01-支付宝扫码支付
           A02-支付宝刷卡支付
           03-支付窗支付
           PG-网银支付
           U01-银联二维码扫码支付
           U03-银联二维码被扫
        */
        [JsonPropertyName("productId")]
        public string ProductId { get; set; }
        //
        [JsonPropertyName("merchantNo")]
        public string MerchantNo { get; set; }


        [JsonPropertyName("orderNo")]
        public string OrderNo { get; set; }


        [JsonPropertyName("orderAmount")]
        public string OrderAmount { get; set; }



        [JsonPropertyName("realAmount")]
        public string RealAmount { get; set; }


        [JsonPropertyName("balance")]
        public string Balance { get; set; }


        [JsonPropertyName("orderDate")]
        public string OrderDate { get; set; }


        [JsonPropertyName("resultCode")]
        public string ResultCode { get; set; }


        [JsonPropertyName("resultMsg")]
        public string ResultMsg { get; set; }


        [JsonPropertyName("instOrderNo")]
        public string InstOrderNo { get; set; }


        [JsonPropertyName("signType")]
        public string SignType { get; set; }


        [JsonPropertyName("digest")]
        public string Digest { get; set; }


      
    }

}
