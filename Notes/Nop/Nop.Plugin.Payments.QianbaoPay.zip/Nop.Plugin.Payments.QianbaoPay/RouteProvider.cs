﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework.Mvc.Routing;
namespace Nop.Plugin.Payments.QianBaoPay
{
    public partial class RouteProvider : IRouteProvider
    {
        /// <summary>
        /// Register routes
        /// </summary>
        /// <param name="routeBuilder">Route builder</param>
        public void RegisterRoutes(IEndpointRouteBuilder endpointRouteBuilder)
        {
            //生成唤起支付页面
            endpointRouteBuilder.MapControllerRoute(QianBaoPayDefaults.InvokeAppName,
                "Plugins/PaymentQianBaoPay/QianBaoPayInvokeApp/",
                new { controller = "PaymentQianBaoPay", action = "InvokeQianBaoApp" }
                );

            endpointRouteBuilder.MapControllerRoute(QianBaoPayDefaults.ScanCodeRouteName,
                 "Plugins/PaymentQianBaoPay/QianBaoPayScanCode/{ordercode}",
                 new { controller = "PaymentQianBaoPay", action = "QianBaoPayScanCode" }
                 //new[] { "Nop.Plugin.Payments.QianBaoPay.Controllers" }
            );
            //MakePayQRCode
            endpointRouteBuilder.MapControllerRoute(QianBaoPayDefaults.GenerateQRCodeRouteName,
                 "Plugins/PaymentQianBaoPay/MakeQRCode",
                 new { controller = "PaymentQianBaoPay", action = "MakeQRCode" }
                 //new[] { "Nop.Plugin.Payments.QianBaoPay.Controllers" }
            );

          
            //电脑网站支付异步通知回调路由名
            endpointRouteBuilder.MapControllerRoute(QianBaoPayDefaults.PagePayNotifyRouteName,
                 "Plugins/PaymentQianBaoPay/Notify",
                 new { controller = "PaymentQianBaoPay", action = "Notify" }
                 //new[] { "Nop.Plugin.Payments.QianBaoPay.Controllers" }
            );
           

            //Return 支付结束，处理返回商户网站的路由名
            endpointRouteBuilder.MapControllerRoute(QianBaoPayDefaults.ReturnRouteName,
                 "Plugins/PaymentQianBaoPay/Return",
                 new { controller = "PaymentQianBaoPay", action = "Return" }
                 //new[] { "Nop.Plugin.Payments.QianBaoPay.Controllers" }
            );
            //钱宝调用异步回调通知的一个补充
            endpointRouteBuilder.MapControllerRoute(QianBaoPayDefaults.PageReturnRouteName,
               "Plugins/PaymentQianBaoPay/PageReturn",
               new { controller = "PaymentQianBaoPay", action = "PageReturn" }
          //new[] { "Nop.Plugin.Payments.QianBaoPay.Controllers" }
          );

        }

        /// <summary>
        /// Gets a priority of route provider
        /// </summary>
        public int Priority
        {
            get { return -1; }
        }
    }
}
