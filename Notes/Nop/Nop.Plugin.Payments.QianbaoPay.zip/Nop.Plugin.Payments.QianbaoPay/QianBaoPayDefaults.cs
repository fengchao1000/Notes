﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.QianBaoPay
{
    public static partial class QianBaoPayDefaults
    {
        /// <summary>
        /// 扫描页面的路由名
        /// </summary>
        
        public const string ScanCodeRouteName = "Plugin.Payments.QianBaoPay.QianBaoPayScanCode";

        /// <summary>
        /// 生成QR code 的路由名
        /// </summary>
        public const string GenerateQRCodeRouteName = "Plugin.Payments.QianBaoPay.MakeQRCode";
        /// <summary>
        /// 扫码支付异步通知回调路由名
        /// </summary>
        public const string PrecreateNotifyRouteName = "Plugin.Payments.QianBaoPay.PrecreateNotify";
        /// <summary>
        /// 电脑网站支付异步通知回调路由名
        /// </summary>
        public const string PagePayNotifyRouteName = "Plugin.Payments.QianBaoPay.PagePayNotify";

        /// 电脑网站支付回调路由名
        /// </summary>
        public const string PageReturnRouteName = "Plugin.Payments.QianBaoPay.PageReturn";


        /// <summary>
        /// 手机网站支付异步通知回调路由名
        /// </summary>
        public const string WapPayNotifyRouteName = "Plugin.Payments.QianBaoPay.WapPayNotify";
        /// <summary>
        /// 支付结束，处理返回商户网站的路由名
        /// </summary>
        public const string ReturnRouteName = "Plugin.Payments.QianBaoPay.Return";

        public const string TradeType = "NATIVE";

        public const string ProductCode = "FAST_INSTANT_TRADE_PAY";

        public const string InvokeAppName = "Plugin.Payments.QianBaoPay.Invoke.App";
        

        // ProductCode = "FAST_INSTANT_TRADE_PAY"

    }
}
