﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.DependencyInjection;
using Nop.Plugin.Payments.QianBaoPay.Models;

namespace Nop.Plugin.Payments.QianBaoPay.Infrastructure
{


    public static class ServiceCollectionExtensions
    {
        public static void AddQianBaoPay(
            this IServiceCollection services)
        {
            services.AddQianBaoPay(null);
        }

        public static void AddQianBaoPay(
            this IServiceCollection services,
            Action<QianBaoPayOptions> setupAction)
        {
            services.AddHttpClient(nameof(QianBaoPayClient));

           // services.AddSingleton<AlipayPublicKeyManager>();
            services.AddSingleton<IQianBaoPayClient, QianBaoPayClient>();

            services.AddSingleton<IQianBaoPayNotifyClient,QianBaoPayNotifyClient>();


            if (setupAction != null)
            {
                services.Configure(setupAction);
            }
        }
    }
}

