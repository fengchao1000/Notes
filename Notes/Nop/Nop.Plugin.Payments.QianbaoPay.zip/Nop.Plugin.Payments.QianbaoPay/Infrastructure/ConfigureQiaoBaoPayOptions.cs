﻿using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Extensions.Options;
using Nop.Core.Infrastructure;
using Nop.Data;
using Nop.Plugin.Payments.QianBaoPay.Models;

namespace Nop.Plugin.Payments.QianBaoPay.Infrastructure
{

    internal class ConfigureQianBaoPayOptions : IConfigureOptions<QianBaoPayOptions>
    {
        //private string[] _schemes;
        //private readonly IHttpContextAccessor _httpContextAccessor;

        public ConfigureQianBaoPayOptions()// string[] schemes, IHttpContextAccessor httpContextAccessor
        {
            //_schemes = schemes ?? throw new ArgumentNullException(nameof(schemes));
            //_httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
        }

        public void Configure(QianBaoPayOptions options)
        {
            //throw new NotImplementedException();
            if (DataSettingsManager.DatabaseIsInstalled)
            {
                var settings = EngineContext.Current.Resolve<QianBaoPaymentSettings>();

                options.SignKey = settings.SignKey;
                options.MsgSender = settings.MsgSender;
                //options.Charset = settings.Charset;
                options.ServerUrl = settings.ServerUrl;
                //options.IsKeyFromFile = false;
                options.VerifyKey = settings.VerifyKey;
                options.SignType = settings.SignType;
                
                options.Version = settings.Version;
            }
        }

        //public void PostConfigure(string name, AlipayOptions options)
        //{
        //    // no schemes means configure them all
        //    //if (_schemes.Length == 0 || _schemes.Contains(name))
        //    //{
        //    //    options.StateDataFormat = new DistributedCacheStateDataFormatter(_httpContextAccessor, name);
        //    //}
        //}
    }

    internal class PostConfigureAlipayOptions : IPostConfigureOptions<QianBaoPayOptions>
    {
        //private string[] _schemes;
        //private readonly IHttpContextAccessor _httpContextAccessor;

        public PostConfigureAlipayOptions()// string[] schemes, IHttpContextAccessor httpContextAccessor
        {
            //_schemes = schemes ?? throw new ArgumentNullException(nameof(schemes));
            //_httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
        }

        public void PostConfigure(string name, QianBaoPayOptions options)
        {
            // no schemes means configure them all
            //if (_schemes.Length == 0 || _schemes.Contains(name))
            //{
            //    options.StateDataFormat = new DistributedCacheStateDataFormatter(_httpContextAccessor, name);
            //}
        }
    }
}
