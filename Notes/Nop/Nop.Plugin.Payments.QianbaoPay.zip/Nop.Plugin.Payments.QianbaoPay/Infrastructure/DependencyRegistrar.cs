﻿using Autofac;

using Microsoft.Extensions.Options;
using Nop.Core.Configuration;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Plugin.Payments.QianBaoPay.Models;

namespace Nop.Plugin.Payments.QianBaoPay.Infrastructure
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        /// <summary>
        /// Register services and interfaces
        /// </summary>
        /// <param name="builder">Container builder</param>
        /// <param name="typeFinder">Type finder</param>
        /// <param name="config">Config</param>
        public virtual void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            //register client
            //builder.RegisterType<DefaultAliPayClient>().As<IAlipayClient>().InstancePerLifetimeScope();
            //builder.RegisterType<DefaultAliPayNotifyClient>().As<IAlipayNotifyClient>().InstancePerLifetimeScope();

            builder.RegisterType<ConfigureQianBaoPayOptions>().As<IConfigureOptions<QianBaoPayOptions>>().SingleInstance();
            builder.RegisterType<PostConfigureAlipayOptions>().As<IPostConfigureOptions<QianBaoPayOptions>>().SingleInstance();
        }

        /// <summary>
        /// Order of this dependency registrar implementation
        /// </summary>
        public int Order
        {
            get { return 2; }
        }
    }
}
