﻿using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Payments.QianBaoPay.Models;
using Nop.Web.Framework.Components;

namespace Nop.Plugin.Payments.QianBaoPay.Components
{
    [ViewComponent(Name = "PaymentQianBaoPay")]
    public class PaymentQianBaoPayViewComponent : NopViewComponent
    {
        public IViewComponentResult Invoke()
        {
            var model = new PaymentInfoModel();
            return View("~/Plugins/Payments.QianBaoPay/Views/PaymentInfo.cshtml", model);
        }
    }
}