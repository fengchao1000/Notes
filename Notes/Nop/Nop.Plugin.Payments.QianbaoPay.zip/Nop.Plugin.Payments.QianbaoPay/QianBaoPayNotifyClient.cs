﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using Nop.Plugin.Payments.QianBaoPay.Parser;
using Nop.Plugin.Payments.QianBaoPay.Models;
namespace Nop.Plugin.Payments.QianBaoPay
{
   public  class QianBaoPayNotifyClient:IQianBaoPayNotifyClient
    {
        public Task<T> ExecuteAsync<T>(HttpRequest request, QianBaoPayOptions options)where T:QianBaoPayObject
        {
            if (options == null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            if (string.IsNullOrEmpty(options.SignType))
            {
                throw new ArgumentNullException(nameof(options.SignType));
            }

            if (string.IsNullOrEmpty(options.VerifyKey))
            {
                throw new ArgumentNullException(nameof(options.VerifyKey));
            }

            var parameters = GetParameters(request);
            var rsp = QianBaoPayDictionaryParser.Parse<T>(parameters);
            CheckNotifySign(parameters, options);
            return Task.FromResult(rsp);
        }
        public IDictionary<string, string> GetParameters(HttpRequest request)
        {
            var parameters = new Dictionary<string, string>();
            if (request.Method == "POST")
            {
                foreach (var iter in request.Form)
                {
                    parameters.Add(iter.Key, iter.Value);
                }
            }
            else
            {
                foreach (var iter in request.Query)
                {
                    parameters.Add(iter.Key, iter.Value);
                }
            }
            return parameters;
        }
        private void CheckNotifySign(IDictionary<string, string> dictionary, QianBaoPayOptions options)
        {
            if (dictionary == null || dictionary.Count == 0)
            {
                throw new Exception("sign check fail: dictionary is Empty!");
            }

            if (!dictionary.TryGetValue(QianBaoPayConstants.Digest, out var sign))
            {
                throw new Exception("sign check fail: sign is Empty!");
            }

            dictionary.Remove(QianBaoPayConstants.Digest);
           // dictionary.Remove("signType");
            var prestr = QianBaoPaySignature.GetSignContent(dictionary);
            if (!QianBaoPaySignature.RSACheckContent(prestr, sign, options.VerifyKey, options.Charset, options.SignType))
            {
                throw new Exception("sign check fail: check Sign Data Fail!");
            }
        }

    }
}
