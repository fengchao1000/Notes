﻿using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Payments.QianBaoPay.Models;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.Payments.QianBaoPay.Controllers
{
    public partial class PaymentQianBaoPayController
    {
        #region Methods

        [AuthorizeAdmin]
        [Area(AreaNames.Admin)]
        public IActionResult Configure()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
                return AccessDeniedView();

            //load settings for a chosen store scope
            var storeScope = _storeContext.ActiveStoreScopeConfiguration;
            var qianBaoPayPaymentSettings = _settingService.LoadSetting<QianBaoPaymentSettings>(storeScope);

            var model = new ConfigurationModel
            {
                AdditionalFee = qianBaoPayPaymentSettings.AdditionalFee,
                AdditionalFeePercentage = qianBaoPayPaymentSettings.AdditionalFeePercentage,
                MerchantId = qianBaoPayPaymentSettings.MsgSender,
                VerifyKey = qianBaoPayPaymentSettings.VerifyKey,
                SignKey = qianBaoPayPaymentSettings.SignKey,
          
                LogLevel = qianBaoPayPaymentSettings.LogLevel,

                Charset = qianBaoPayPaymentSettings.Charset,
               
                ServerUrl = qianBaoPayPaymentSettings.ServerUrl,
                SignType = qianBaoPayPaymentSettings.SignType,
                Version = qianBaoPayPaymentSettings.Version,

                ActiveStoreScopeConfiguration = storeScope
            };
            if (storeScope > 0)
            {
                model.MerchantId_OverrideForStore = _settingService.SettingExists(qianBaoPayPaymentSettings, x => x.MsgSender, storeScope);
                model.VerifyKey_OverrideForStore = _settingService.SettingExists(qianBaoPayPaymentSettings, x => x.VerifyKey, storeScope);
                model.SignKey_OverrideForStore = _settingService.SettingExists(qianBaoPayPaymentSettings, x => x.SignKey, storeScope);
                 model.LogLevel_OverrideForStore = _settingService.SettingExists(qianBaoPayPaymentSettings, x => x.LogLevel, storeScope);

                model.Charset_OverrideForStore = _settingService.SettingExists(qianBaoPayPaymentSettings, x => x.Charset, storeScope);
              
                model.ServerUrl_OverrideForStore = _settingService.SettingExists(qianBaoPayPaymentSettings, x => x.ServerUrl, storeScope);
                model.SignType_OverrideForStore = _settingService.SettingExists(qianBaoPayPaymentSettings, x => x.SignType, storeScope);
                model.Version_OverrideForStore = _settingService.SettingExists(qianBaoPayPaymentSettings, x => x.Version, storeScope);

                model.AdditionalFee_OverrideForStore = _settingService.SettingExists(qianBaoPayPaymentSettings, x => x.AdditionalFee, storeScope);
                model.AdditionalFeePercentage_OverrideForStore = _settingService.SettingExists(qianBaoPayPaymentSettings, x => x.AdditionalFeePercentage, storeScope);
            }

            return View("~/Plugins/Payments.QianBaoPay/Views/Configure.cshtml", model);
        }

        [HttpPost]
        [AuthorizeAdmin]
        [Area(AreaNames.Admin)]
        public IActionResult Configure(ConfigurationModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
                return AccessDeniedView();

            if (!ModelState.IsValid)
                return Configure();

            //load settings for a chosen store scope
            var storeScope = _storeContext.ActiveStoreScopeConfiguration;
            var qianBaoPayPaymentSettings = _settingService.LoadSetting<QianBaoPaymentSettings>(storeScope);

            //save settings
            qianBaoPayPaymentSettings.MsgSender = model.MerchantId;
            qianBaoPayPaymentSettings.VerifyKey = model.VerifyKey;
            qianBaoPayPaymentSettings.SignKey = model.SignKey;
            qianBaoPayPaymentSettings.LogLevel = model.LogLevel;

         
              qianBaoPayPaymentSettings.ServerUrl = model.ServerUrl;
            qianBaoPayPaymentSettings.SignType = model.SignType;
            qianBaoPayPaymentSettings.Version = model.Version;

            qianBaoPayPaymentSettings.AdditionalFee = model.AdditionalFee;
            qianBaoPayPaymentSettings.AdditionalFeePercentage = model.AdditionalFeePercentage;

            /* We do not clear cache after each setting update.
             * This behavior can increase performance because cached settings will not be cleared
             * and loaded from database after each update */
            _settingService.SaveSettingOverridablePerStore(qianBaoPayPaymentSettings, x => x.MsgSender, model.MerchantId_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(qianBaoPayPaymentSettings, x => x.VerifyKey, model.VerifyKey_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(qianBaoPayPaymentSettings, x => x.SignKey, model.SignKey_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(qianBaoPayPaymentSettings, x => x.LogLevel, model.LogLevel_OverrideForStore, storeScope, false);

            _settingService.SaveSettingOverridablePerStore(qianBaoPayPaymentSettings, x => x.ServerUrl, model.ServerUrl_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(qianBaoPayPaymentSettings, x => x.SignType, model.SignType_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(qianBaoPayPaymentSettings, x => x.Version, model.Version_OverrideForStore, storeScope, false);

            _settingService.SaveSettingOverridablePerStore(qianBaoPayPaymentSettings, x => x.AdditionalFee, model.AdditionalFee_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(qianBaoPayPaymentSettings, x => x.AdditionalFeePercentage, model.AdditionalFeePercentage_OverrideForStore, storeScope, false);

            //now clear settings cache
            _settingService.ClearCache();

            _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));

            return Configure();
        }

        #endregion Methods
    }
}