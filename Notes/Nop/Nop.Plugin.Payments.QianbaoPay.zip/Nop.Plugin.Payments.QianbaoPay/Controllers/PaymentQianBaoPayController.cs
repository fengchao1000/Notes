﻿

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.Extensions.Options;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Payments.QianBaoPay.Models;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Security;
using Nop.Web.Framework.Controllers;
using QRCoder;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Nop.Plugin.Payments.QianBaoPay.Controllers
{
    public partial class PaymentQianBaoPayController : BasePaymentController
    {
        #region Fields

        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IOrderService _orderService;
        private readonly IPaymentService _paymentService;
        private readonly IPermissionService _permissionService;
        private readonly ILocalizationService _localizationService;
        private readonly INotificationService _notificationService;
        private readonly ISettingService _settingService;

        private readonly IUrlHelperFactory _urlHelperFactory;
        private readonly IActionContextAccessor _actionContextAccessor;

        private readonly ILogger _logger;
        private readonly IStoreContext _storeContext;
        private readonly IWebHelper _webHelper;
        private readonly IWorkContext _workContext;
        private readonly ShoppingCartSettings _shoppingCartSettings;

        private readonly IQianBaoPayClient _payClient;
        private readonly IQianBaoPayNotifyClient _notifyClient;
        private readonly QianBaoPaymentSettings _qianBaoPayPaymentSettings;
        private readonly IOptions<QianBaoPayOptions> _optionsAccessor;

        #endregion

        #region Ctor

        public PaymentQianBaoPayController(
            IGenericAttributeService genericAttributeService,
            IOrderProcessingService orderProcessingService,
            IOrderService orderService,
            IPaymentService paymentService,
            IPermissionService permissionService,
            ILocalizationService localizationService,
            IUrlHelperFactory urlHelperFactory,
            IActionContextAccessor actionContextAccessor,
            ILogger logger,
            INotificationService notificationService,
            ISettingService settingService,
            IStoreContext storeContext,
            IWebHelper webHelper,
            IWorkContext workContext,
            IQianBaoPayClient payClient,
            IQianBaoPayNotifyClient notifyClient,
            ShoppingCartSettings shoppingCartSettings,
            QianBaoPaymentSettings qianBaoPayPaymentSettings,
            IOptions<QianBaoPayOptions> optionsAccessor)
        {
            this._genericAttributeService = genericAttributeService;
            this._orderService = orderService;
            this._orderProcessingService = orderProcessingService;
            this._paymentService = paymentService;
            this._permissionService = permissionService;
            this._localizationService = localizationService;
            this._logger = logger;
            this._notificationService = notificationService;
            this._settingService = settingService;
            this._shoppingCartSettings = shoppingCartSettings;
            this._storeContext = storeContext;
            this._webHelper = webHelper;
            this._workContext = workContext;

            _urlHelperFactory = urlHelperFactory;
            _actionContextAccessor = actionContextAccessor;

            _payClient = payClient;
            _notifyClient = notifyClient;
            _qianBaoPayPaymentSettings = qianBaoPayPaymentSettings;
            _optionsAccessor = optionsAccessor;
        }

        #endregion

        #region Methods

        /// <summary>
        /// 选择钱宝支付后，重定向到扫码页面
        /// </summary>
        /// <param name="ordercode"></param>
        /// <returns></returns>
        public IActionResult QianBaoPayScanCode(string ordercode)
        {
            var model = new QianBaoPayScanCodeModel();
            model.OrderCode = ordercode;
            //this.RouteData
            return View("~/Plugins/Payments.QianBaoPay/Views/QianBaoPayScanCode.cshtml", model);
        }
        public IActionResult InvokeQianBaoApp()
        {
            var form = Request.Query["form"];
         //   form = HttpUtility.UrlDecode(form);
            return Content(form, "text/html", Encoding.UTF8);
        }
        /// <summary>
        /// 获取到钱支付二维码
        /// </summary>
        /// <param name="ordercode"></param>
        /// <returns></returns>
        public async Task<IActionResult> MakeQRCode(string ordercode)
        {
            return NoContent();
            /*
            if(String.IsNullOrEmpty(ordercode) || ordercode.Length != 32)
            {
                return File("/content/default-image.gif", "image/gif");
            }
            var order = _orderService.GetOrderByGuid(new Guid( ordercode));
            if (order == null)
            {
                return File("/content/default-image.gif", "image/gif");
            }
            var urlHelper = _urlHelperFactory.GetUrlHelper(_actionContextAccessor.ActionContext);

            var model = new AlipayTradePrecreateModel
            {
                Body = GetBody(order,_orderService),
                OutTradeNo = order.OrderGuid.ToString("N"),
                TotalAmount = order.OrderTotal.ToString("#0.00"),
                Subject = GetBody(order,_orderService),
            };
            var request = new AlipayTradePrecreateRequest();
            request.SetBizModel(model);
            request.SetNotifyUrl(urlHelper.RouteUrl(QianBaoPayDefaults.PrecreateNotifyRouteName));
            var response = await _payClient.ExecuteAsync(request,_optionsAccessor.Value);
            
            // response.CodeUrl 给前端生成二维码
            ViewData["qrcode"] = response.QrCode; //  "qr_code": "https://qr.alipay.com/bavh4wjlxf12tper3a"
            ViewData["response"] = response.Body;

            //将字符串生成二维码图片
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(response.QrCode, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);
            //Bitmap image = qrCodeEncoder.Encode(result.CodeUrl, Encoding.Default);

            //保存为PNG到内存流  
            MemoryStream ms = new MemoryStream();
            qrCodeImage.Save(ms, ImageFormat.Jpeg);

            return File(ms.GetBuffer(), "image/jpeg");  
            */
        }

        [HttpPost]
        public async Task<IActionResult> Notify()
        {
          // string productId= Request.Query["productId"].ToString();
           // return NoContent();
            
            try
            {
                var notify = await _notifyClient.ExecuteAsync<QianBaoPayNotify>(Request,_optionsAccessor.Value);
                if ("交易成功" == notify.ResultMsg)
                {
                    var order = _orderService.GetOrderByGuid(new Guid(notify.OrderNo));
                    if (order == null)
                    {
                        return new ContentResult { Content = "failure", ContentType = "text/plain", StatusCode = 200 };
                        
                    }
                    int paidFee = notify.RealAmount is null ? System.Convert.ToInt32(notify.OrderAmount) : System.Convert.ToInt32(notify.OrderAmount);
                    if (paidFee != Convert.ToInt32((order.OrderTotal * 100).ToString()))
                    {
                        return new ContentResult { Content = "success", ContentType = "text/plain", StatusCode = 200 };
                    }
                    if (order != null && _orderProcessingService.CanMarkOrderAsPaid(order))
                    {
                        order.AuthorizationTransactionCode = notify.OrderNo;
                     //   order.AuthorizationTransactionId = notify.TransactionId;
                      //  order.SubscriptionTransactionId = notify.TransactionId;
                       // order.CaptureTransactionId = notify.TransactionId;
                        order.CaptureTransactionResult = notify.ResultCode;
                        _orderProcessingService.MarkOrderAsPaid(order);
                    }
                    return  new ContentResult { Content = "Ok", ContentType = "text/plain", StatusCode = 200 };
                }
                return NoContent();
            }
            catch(Exception ex)
            {

                return NoContent();
            }
            
        }

        [HttpPost]
        public async Task<IActionResult> PageReturn()
        {
            try
            {
                var notify = await _notifyClient.ExecuteAsync<QianBaoPayNotify>(Request, _optionsAccessor.Value);
                if ("交易成功" == notify.ResultMsg)
                {
                    var order = _orderService.GetOrderByGuid(new Guid(notify.OrderNo));
                    if (order == null)
                    {
                        return new ContentResult { Content = "failure", ContentType = "text/plain", StatusCode = 200 };

                    }
                    int paidFee = notify.RealAmount is null ? System.Convert.ToInt32(notify.OrderAmount) : System.Convert.ToInt32(notify.OrderAmount);
                    if (Math.Abs(paidFee-order.OrderTotal * 100)>1)
                    {
                        _logger.Information(notify.OrderNo + "付款数目不一致");
                        return new ContentResult { Content = "failure", ContentType = "text/plain", StatusCode = 200 };
                    }
                    if (order != null && _orderProcessingService.CanMarkOrderAsPaid(order))
                    {
                        order.AuthorizationTransactionCode = notify.OrderNo;
                        //   order.AuthorizationTransactionId = notify.TransactionId;
                        //  order.SubscriptionTransactionId = notify.TransactionId;
                        // order.CaptureTransactionId = notify.TransactionId;
                        order.CaptureTransactionResult = notify.ResultCode;
                        _orderProcessingService.MarkOrderAsPaid(order);
                    }
                    return RedirectToRoute("CustomerOrders");
                    //   return new ContentResult { Content = "Ok", ContentType = "text/plain", StatusCode = 200 };
                }
                // return NoContent();
                return RedirectToRoute("CustomerOrders");
            }
            catch (Exception ex)
            {
                return RedirectToRoute("CustomerOrders");
                // return NoContent();
            }

        }


        // 对于PC网站支付的交易，在用户支付完成之后，钱宝会根据API中商户传入的return_url参数，
        // 通过GET请求的形式将部分支付结果参数通知到商户系统。
        public ActionResult Return(string orderId)
        {
            if (String.IsNullOrEmpty(_qianBaoPayPaymentSettings.ReturnRouteName))
            {
                return RedirectToRoute("CustomerOrders");
            }
            else
            {
                // https://github.com/essensoft/payment/blob/dev/samples/WebApplicationSample/Controllers/AlipayController.cs
                //var notify = _notifyClient.ExecuteAsync<AlipayTradePagePayReturn>(Request, _optionsAccessor.Value);
                //if (string.IsNullOrEmpty(orderId))
                //{
                //}
                //else
                //{

                //}
                return RedirectToRoute(_qianBaoPayPaymentSettings.ReturnRouteName, new { orderId = orderId });
            }
        }

        //private IActionResult MarkOrderAsPaid<T>(T notify)
        //{
        //    var order = _orderService.GetOrderByGuid(new Guid(notify.OutTradeNo));
        //    if (order == null)
        //    {
        //        return AlipayNotifyResult.Failure;
        //    }
        //    if (notify.ReceiptAmount != Convert.ToInt32(order.OrderTotal * 100).ToString())
        //    {
        //        return AlipayNotifyResult.Failure;
        //    }
        //    if (order != null && _orderProcessingService.CanMarkOrderAsPaid(order))
        //    {
        //        order.AuthorizationTransactionCode = notify.TradeNo;
        //        order.AuthorizationTransactionId = notify.TradeNo;
        //        order.SubscriptionTransactionId = notify.TradeNo;
        //        order.CaptureTransactionId = notify.TradeNo;
        //        order.CaptureTransactionResult = notify.NotifyTime;
        //        _orderProcessingService.MarkOrderAsPaid(order);
        //    }
        //    return AlipayNotifyResult.Success;
        //}

        #endregion

        #region

        public static string GetBody(Order order,IOrderService orderService, int length = 63)
        {
            string body = "";
            int p = 0;
            var orderItems = orderService.GetOrderItems(order.Id);
            int count = orderItems.Count;

            foreach (Core.Domain.Orders.OrderItem item in orderItems.OrderBy(oi => oi.Id))
            {
                body = body + orderService.GetProductByOrderItemId(item.Id).Name;
                if (p < count - 1)
                {
                    body = body + "|";
                }
                p++;
            }
            if (body.Length > length)
            {
                body = body.Substring(0, length);
            }
            return body.Trim().Replace('&', '_').Replace('=', '_');
        }

        public string GetBody(IList<Order> orders, IOrderService orderService,int length = 224)
        {
            string body = "";

            if (orders.Count > 0)
            {
                length = length / orders.Count;
            }

            foreach (var order in orders)
            {
                var orderItems = orderService.GetOrderItems(order.Id);
                int count = orderItems.Count;
                if (count == 0)
                    continue;
                int p = 0;
                string tmp = "";
                foreach (Core.Domain.Orders.OrderItem item in orderItems)
                {
                    tmp = tmp + orderService.GetProductByOrderItemId(item.Id).Name;
                    if (p < count - 1)
                    {
                        tmp = tmp + "|";
                    }
                    p++;
                }
                if (tmp.Length > length)
                {
                    tmp = tmp.Substring(0, length);
                }

                body += tmp;
            }
            return body;
        }

        #endregion
    }
}