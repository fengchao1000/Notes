﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Threading.Tasks;
using Nop.Plugin.Payments.QianBaoPay.Models;

using Ubiety.Dns.Core;

namespace Nop.Plugin.Payments.QianBaoPay
{
    public class QianBaoPayClient:IQianBaoPayClient
    {
        private readonly IHttpClientFactory _httpClientFactory;
        public QianBaoPayClient(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }
        public async Task<QianBaoResponse> ExecuteAsync(QianBaoRequest request, QianBaoPayOptions options) 
        {
            if (options == null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            if (string.IsNullOrEmpty(options.MsgSender))
            {
                throw new ArgumentNullException(nameof(options.MsgSender));
            }

            if (string.IsNullOrEmpty(options.SignType))
            {
                throw new ArgumentNullException(nameof(options.SignType));
            }

            if (string.IsNullOrEmpty(options.SignKey))
            {
                throw new ArgumentNullException(nameof(options.SignKey));
            }

            if (string.IsNullOrEmpty(options.ServerUrl))
            {
                throw new ArgumentNullException(nameof(options.ServerUrl));
            }

            //var apiVersion = string.IsNullOrEmpty(request.GetApiVersion()) ? options.Version : request.GetApiVersion();

            // 添加协议级请求参数
            int orderAmount = (int)(request.OrderAmount * 100);
            string productName = request.ProductName;
            if (productName.Length > 31)
                productName = productName.Substring(0, 30);
            var txtParams = new QianBaoPayDictionary()
            {
                {QianBaoPayConstants.Name, options.Name },
                { QianBaoPayConstants.Version,options.Version },
                { QianBaoPayConstants.MsgSender, options.MsgSender },
                { QianBaoPayConstants.Charset, options.Charset },
                { QianBaoPayConstants.SendTime, DateTime.Now },
                { QianBaoPayConstants.SignType, options.SignType },
                { QianBaoPayConstants.OrderNo, request.OrderNo },
                { QianBaoPayConstants.OrderAmount, orderAmount },
                { QianBaoPayConstants.OrderTime, request.OrderTime },
                { QianBaoPayConstants.NotifyUrl, request.NotifyUrl },
                { QianBaoPayConstants.PageUrl, request.PageUrl },
                { QianBaoPayConstants.ProductName,productName},
                { QianBaoPayConstants.BuyerIp,request.BuyerIp},
                {QianBaoPayConstants.PayType,"PT001" }
            };

            // 序列化BizModel
            //txtParams = SerializeBizModel(txtParams, request);

            // 添加签名参数
            var signContent = QianBaoPaySignature.GetSignContent(txtParams);

            txtParams.Add(QianBaoPayConstants.SignMsg, QianBaoPaySignature.RSASignContent(signContent, options.SignKey, options.Charset, options.SignType));
            txtParams.Add(QianBaoPayConstants.PayerMobileNo, request.PayerMobileNo);
          //  txtParams.Add(QianBaoPayConstants.AccNO, request.AccNo);


            string reqMethod = "GET";
            string body;

            // 是否需要上传文件

            if (reqMethod.ToUpperInvariant() == "GET")
            {
                var url = options.ServerUrl;
                if (txtParams != null && txtParams.Count > 0)
                {
                    if (url.Contains("?"))
                    {
                        url += "&" + QianBaoPayUtility.BuildQuery(txtParams);
                    }
                    else
                    {
                        url += "?" + QianBaoPayUtility.BuildQuery(txtParams);
                    }
                }
                body = url;
            }
            else
            {
                var client = _httpClientFactory.CreateClient(nameof(QianBaoPayClient));
                    body = await client.PostAsync(options.ServerUrl, txtParams);
   
   
            }
            QianBaoResponse rsp = new QianBaoResponse();
            rsp.Body = body;
            return rsp;
        }
       


    }
}
