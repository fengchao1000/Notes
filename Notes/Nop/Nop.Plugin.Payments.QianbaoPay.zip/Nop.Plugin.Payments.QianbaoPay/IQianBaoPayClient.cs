﻿using System;
using System.Collections.Generic;
using System.Text;
using Nop.Plugin.Payments.QianBaoPay.Models;
using System.Threading.Tasks;

namespace Nop.Plugin.Payments.QianBaoPay
{
    public interface IQianBaoPayClient
    {
        /// <summary>
        /// 执行 QianBao Pay API请求。
        /// </summary>
        /// <param name="request">具体的QianBao Pay API请求</param>
        /// <param name="options">配置选项</param>
        /// <returns>领域对象</returns>
        Task<QianBaoResponse> ExecuteAsync(QianBaoRequest request, QianBaoPayOptions options);
    }
}
