﻿using Nop.Core.Configuration;
using System.Security.Cryptography;
using Essensoft.AspNetCore.Payment.Security;
using Microsoft.Extensions.Logging;

namespace Nop.Plugin.Payments.QianBaoPay
{
    public partial class QianBaoPaymentSettings : ISettings
    {
        internal RSAParameters PrivateRSAParameters;
        internal RSAParameters PublicRSAParameters;

        private string signKey;
        private string verifyKey;

        /// <summary>
        /// 加签密钥
        /// </summary>

        public string SignKey
        {
            get => signKey;
            set
            {
                signKey = value;
              
            }
        }
        /// <summary>
        /// 商户号
        /// </summary>
        public string MsgSender { get; set; }

        /// <summary>
        /// 验签密钥
        /// </summary>
        public string VerifyKey
        {
            get => verifyKey;
            set
            {
                verifyKey = value;
            }
        }
      
    
        /// <summary>
        /// 服务地址
        /// </summary>
        public string ServerUrl { get; set; } = "https://ipay.fortunebill.com/mas/cashier.do"; // https://ipay.fortunebill.com/mas/cashier.do

        /// <summary>
        /// 数据格式
        /// </summary>

        public string Version { get; set; } = "V1.0";

        /// <summary>
        /// 签名方式
        /// </summary>
        public string SignType { get; set; } = "RSA2";

        /// <summary>
        /// 编码格式
        /// </summary>
        public string Charset { get; } = "UTF-8";
    
        /// <summary>
        /// 日志等级
        /// </summary>
        public LogLevel LogLevel { get; set; } = LogLevel.Error;

        /// <summary>
        /// Gets or sets a value indicating whether to "additional fee" is specified as percentage. true - percentage, false - fixed value.
        /// </summary>
        public bool AdditionalFeePercentage { get; set; }

        /// <summary>
        /// Gets or sets an additional fee
        /// </summary>
        public decimal AdditionalFee { get; set; }

        public string ReturnRouteName { get; set; }
    }
}
